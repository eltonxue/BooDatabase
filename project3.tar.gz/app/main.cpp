#include "HashMap.hpp"
#include "UserInterface.hpp"

int main()
{
	UserInterface program;
	program.start();

    return 0;
}

